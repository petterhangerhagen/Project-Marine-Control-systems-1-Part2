%Plotting of Simulations 
simulation = "Simulation5";

if simulation == "Simulation1"

%Simulation 1
    Time = Simulation1{16}.Values.Time;
   
    North = Simulation1{16}.Values.Data(:,1);
    East = Simulation1{16}.Values.Data(:,2);
    Heading  = Simulation1{16}.Values.Data(:,3);
    
   
    X = []; 
    Y = [];
    U = [];
    V = [];
    
     for i = 1:60:3000
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
     end
    
    figure(1);
    clf(figure(1)); 
    plot(East,North); hold on; grid on;
    quiver(X,Y,U,V,0.33);
    legend("Ship trajectory","Ship heading"); 
    xlim([-80 10]);
    ylim([-80 10]);
    clf(figure(2));
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    
    plot(ax1,Time ,North); hold on; grid on;
    legend("North"); 
    xlabel("Time [s]"); 
    ylabel("[m]");

    ax2 = nexttile; 
    plot(ax2,Time,East); hold on; grid on;  
    
    legend("East");
    xlabel("Time [s]"); 
    ylabel("[m]");
    

    ax3 = nexttile; 
    plot(ax3,Time,Heading*180/pi); hold on; grid on;  
    
    legend("Heading");
    xlabel("Time [s]"); 
    ylabel("[deg]");
    
    

elseif simulation == "Simulation2"
%Simulation 2 
%Time 
    Time = Simulation2{16}.Values.Time;

    %References 
    %EtaRef 
    NorthRef = Simulation2{15}.Values.Data(:,1);
    EastRef = Simulation2{15}.Values.Data(:,2);
    HeadingRef = Simulation2{15}.Values.Data(:,3);

    %NuRef
    NorthNuRef = Simulation2{16}.Values.Data(:,1);
    EastNuRef = Simulation2{16}.Values.Data(:,2);
    HeadingNuRef = Simulation2{16}.Values.Data(:,3);

    %Real values
    %Eta
    North = Simulation2{17}.Values.Data(:,1);
    East = Simulation2{17}.Values.Data(:,2);
    Heading  = Simulation2{17}.Values.Data(:,3);

    %Nu
    NorthNu = Simulation2{18}.Values.Data(:,1);
    EastNu = Simulation2{18}.Values.Data(:,2);
    HeadingNu = Simulation2{18}.Values.Data(:,2);

    %Estimations
    %Eta
    NorthEst = Simulation2{9}.Values.Data(:,1);
    EastEst = Simulation2{9}.Values.Data(:,2);
    HeadingEst = Simulation2{9}.Values.Data(:,3); 

    %Nu 
    NorthNuEst = Simulation2{10}.Values.Data(:,1);
    EastNuEst = Simulation2{10}.Values.Data(:,2);
    HeadingNuEst = Simulation2{10}.Values.Data(:,3);

    %Thrusters 
    U1 = Simulation2{21}.Values.Data(:,1);
    U2 = Simulation2{21}.Values.Data(:,2);
    U3 = Simulation2{21}.Values.Data(:,3);
    U4 = Simulation2{21}.Values.Data(:,4);
    U5 = Simulation2{21}.Values.Data(:,5);
    
    %Alpha 
    A1 = Simulation2{20}.Values.Data(:,1);
    A2 = Simulation2{20}.Values.Data(:,2);
    A3 = Simulation2{20}.Values.Data(:,3);
    A4 = Simulation2{20}.Values.Data(:,4);
    A5 = Simulation2{20}.Values.Data(:,5);
    
    %Thruster Dynamics 
    Thrust1 = Simulation2{19}.Values.Data(:,1);
    Thrust2 = Simulation2{19}.Values.Data(:,2);
    Thrust6 = Simulation2{19}.Values.Data(:,6);
    
    %Controller Tau
    Tau1 = Simulation2{5}.Values.Data(:,1); 
    Tau2 = Simulation2{5}.Values.Data(:,2);
    Tau6 = Simulation2{5}.Values.Data(:,6);
    
    
    %Thruster Failure 
    %References 
    %EtaRef 
    NorthRefF = Simulation2ThrusterFailure{15}.Values.Data(:,1);
    EastRefF = Simulation2{15}.Values.Data(:,2);
    HeadingRefF = Simulation2ThrusterFailure{15}.Values.Data(:,3);

    %NuRef
    NorthNuRefF = Simulation2ThrusterFailure{16}.Values.Data(:,1);
    EastNuRefF = Simulation2ThrusterFailure{16}.Values.Data(:,2);
    HeadingNuRefF = Simulation2ThrusterFailure{16}.Values.Data(:,3);

    %Real values
    %Eta
    NorthF = Simulation2ThrusterFailure{17}.Values.Data(:,1);
    EastF = Simulation2ThrusterFailure{17}.Values.Data(:,2);
    HeadingF  = Simulation2ThrusterFailure{17}.Values.Data(:,3);

    %Nu
    NorthNuF = Simulation2ThrusterFailure{18}.Values.Data(:,1);
    EastNuF = Simulation2ThrusterFailure{18}.Values.Data(:,2);
    HeadingNuF = Simulation2ThrusterFailure{18}.Values.Data(:,2);

    %Estimations
    %Eta
    NorthEstF = Simulation2ThrusterFailure{9}.Values.Data(:,1);
    EastEstF = Simulation2ThrusterFailure{9}.Values.Data(:,2);
    HeadingEstF = Simulation2ThrusterFailure{9}.Values.Data(:,3); 

    %Nu 
    NorthNuEstF = Simulation2ThrusterFailure{10}.Values.Data(:,1);
    EastNuEstF = Simulation2ThrusterFailure{10}.Values.Data(:,2);
    HeadingNuEstF = Simulation2ThrusterFailure{10}.Values.Data(:,3);

    %Thrusters 
    U1F = Simulation2ThrusterFailure{21}.Values.Data(:,1);
    U2F = Simulation2ThrusterFailure{21}.Values.Data(:,2);
    U3F = Simulation2ThrusterFailure{21}.Values.Data(:,3);
    U4F = Simulation2ThrusterFailure{21}.Values.Data(:,4);
    U5F = Simulation2ThrusterFailure{21}.Values.Data(:,5);
    
    %Alpha 
    A1F = Simulation2ThrusterFailure{20}.Values.Data(:,1);
    A2F = Simulation2ThrusterFailure{20}.Values.Data(:,2);
    A3F = Simulation2ThrusterFailure{20}.Values.Data(:,3);
    A4F = Simulation2ThrusterFailure{20}.Values.Data(:,4);
    A5F = Simulation2ThrusterFailure{20}.Values.Data(:,5);
    
    %Thruster Dynamics 
    Thrust1F = Simulation2ThrusterFailure{19}.Values.Data(:,1);
    Thrust2F = Simulation2ThrusterFailure{19}.Values.Data(:,2);
    Thrust6F = Simulation2ThrusterFailure{19}.Values.Data(:,6);
    
    %Controller Tau
    Tau1F = Simulation2ThrusterFailure{5}.Values.Data(:,1); 
    Tau2F = Simulation2ThrusterFailure{5}.Values.Data(:,2);
    Tau6F = Simulation2ThrusterFailure{5}.Values.Data(:,6);
    
    
    %Plot Simulation 2 
    figure(1);
    clf(figure(1));
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    
    plot(ax1,Time ,North); hold on; grid on; 
    plot(ax1,Time, NorthRef); hold on; grid on; 
    legend("North","North reference"); 
    xlabel("Time [s]"); 
    ylabel("[m]");

    ax2 = nexttile; 
    plot(ax2,Time,East); hold on; grid on;  
    plot(ax2,Time,EastRef); hold on; grid on; 
    legend("East","East reference");
    xlabel("Time [s]"); 
    ylabel("[m]");
    ylim([-60 5]);

    ax3 = nexttile; 
    plot(ax3,Time,Heading*180/pi); hold on; grid on;  
    plot(ax3,Time,HeadingRef*180/pi); hold on; grid on; 
    legend("Heading","Heading reference");
    xlabel("Time [s]"); 
    ylabel("[deg]");
    ylim([-50 10]);
    
    
    %Plot With Thruster Failure
    figure(2);
    clf(figure(2));
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    title(ax1,"Thruster Failure")
    plot(ax1,Time , NorthF); hold on; grid on;
    plot(ax1,Time, NorthRefF); hold on; grid on;
    legend("North","North reference"); 
    xlabel("Time [s]"); 
    ylabel("[m]");

    ax2 = nexttile; 
    plot(ax2,Time,EastF); hold on; grid on;  
    plot(ax2,Time,EastRefF); hold on;
    legend("East","East reference");
    xlabel("Time [s]"); 
    ylabel("[m]");
    ylim([-60 5]);

    ax3 = nexttile; 
    plot(ax3,Time,Heading*180/pi); hold on; grid on; 
    plot(ax3,Time,HeadingRef*180/pi); hold on; grid on; 
    legend("Heading","Heading reference");
    xlabel("Time [s]"); 
    ylabel("[deg]");
    ylim([-50 10]);
    sgtitle("Thruster Failure");
    
    
     %Heading visualization: 
    X = []; 
    Y = [];
    U = [];
    V = [];
    %Thruster Failure
    XF = []; 
    YF = [];
    UF = [];
    VF = [];
    
    for i = 1:1:1
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
        
        XF = [XF EastF(i)];
        YF = [YF NorthF(i)];
        UF = [UF sin(HeadingF(i))];
        VF = [VF cos(HeadingF(i))];
    end

    for i = 2000:100:2800
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
        
        XF = [XF EastF(i)];
        YF = [YF NorthF(i)];
        UF = [UF sin(HeadingF(i))];
        VF = [VF cos(HeadingF(i))];
    end

    for i = 4000:100:6000
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
        
        XF = [XF EastF(i)];
        YF = [YF NorthF(i)];
        UF = [UF sin(HeadingF(i))];
        VF = [VF cos(HeadingF(i))];
    end

    for i = 7700:100:9400
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
        
        XF = [XF EastF(i)];
        YF = [YF NorthF(i)];
        UF = [UF sin(HeadingF(i))];
        VF = [VF cos(HeadingF(i))];
    end
    for i = 10000:500:11000
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
        
        XF = [XF EastF(i)];
        YF = [YF NorthF(i)];
        UF = [UF sin(HeadingF(i))];
        VF = [VF cos(HeadingF(i))];
    end
    for i = 11000:100:11200
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
        XF = [XF EastF(i)];
        YF = [YF NorthF(i)];
        UF = [UF sin(HeadingF(i))];
        VF = [VF cos(HeadingF(i))];
    end
    for i = 11200:75:13000
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
        
        XF = [XF EastF(i)];
        YF = [YF NorthF(i)];
        UF = [UF sin(HeadingF(i))];
        VF = [VF cos(HeadingF(i))];
    end
    
    
    figure(3);
    clf(figure(3));
    plot(East,North); hold on;
    plot(EastRef,NorthRef); hold on;
    quiver(X,Y,U,V,0.33); hold on; grid on; 
    xlabel("East [m]");
    ylabel("North [m]"); 
    legend("Pos","Reference","Heading");
    xlim([-60 10]);
    ylim([-10 60]);
    set(gca,'XTick', [-60,-50,-40,-30,-20,-10,0,10]);
    set(gca,'YTick', [-10,0,10,20,30,40,50,60,70]);
      
    
    figure(4);
    clf(figure(4));
    plot(EastF,NorthF); hold on;
    plot(EastRefF,NorthRefF); hold on;
    quiver(XF,YF,UF,VF,0.33); hold on; grid on; 
    xlabel("East [m]");
    ylabel("North [m]"); 
    legend("Pos","Reference","Heading");
    sgtitle("Thruster Failure");
    
    figure(5); 
    clf(figure(5));
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time,Tau1); hold on; grid on; 
    plot(ax1,Time,Thrust1); hold on; grid on; 
    legend("Controller", "Thruster dynamics");
    xlabel("Time [s]"); 
    ylabel("N");
    
    ax2 = nexttile; 
    plot(ax2,Time,Tau2); hold on; grid on; 
    plot(ax2,Time,Thrust2); hold on; grid on; 
    legend("Controller", "Thruster dynamics");
    xlabel("Time [s]"); 
    ylabel("N");
    
    ax3 = nexttile;
    plot(ax3,Time,Tau6); hold on; grid on; 
    plot(ax3,Time,Thrust6); hold on; grid on; 
    legend("Controller", "Thruster dynamics");
    xlabel("Time [s]"); 
    ylabel("N");
    
  
    
    figure(6);
    clf(figure(6));
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time,Tau1F); hold on; grid on; 
    plot(ax1,Time,Thrust1F); hold on; grid on; 
    legend("Controller", "Thruster dynamics");
    xlabel("Time [s]"); 
    ylabel("N");
    
    ax2 = nexttile; 
    plot(ax2,Time,Tau2F); hold on; grid on; 
    plot(ax2,Time,Thrust2F); hold on; grid on; 
    legend("Controller", "Thruster dynamics");
    xlabel("Time [s]"); 
    ylabel("N");
    
    ax3 = nexttile;
    plot(ax3,Time,Tau6F); hold on; grid on; 
    plot(ax3,Time,Thrust6F); hold on; grid on; 
    legend("Controller", "Thruster dynamics");
    sgtitle("Thruster Failure");
    xlabel("Time [s]"); 
    ylabel("N");
    
    limit = 1700; 
    figure(7); 
    clf(figure(7));
    t = tiledlayout(5,1); 
    ax1 = nexttile; 
    plot(ax1,Time , U1); hold on; grid on;
    plot(ax1,Time, U1F); hold on; grid on;
    line([0 limit], [125*10^3 125*10^3],'Color', 'red')
    line([0 limit], [-125*10^3 -125*10^3],'Color', 'red')
    legend("Thruster 1","Thruster 1 w/ fail"); 
    xlabel("Time [s]"); 
    ylabel("N");
    xlim([0 1700]);
    ylim([-170e3 170e3]);

    ax2 = nexttile; 
    plot(ax2,Time , U2); hold on; grid on; 
    plot(ax2,Time,U2F); hold on; grid on; 
    line([0 limit], [125*10^3 125*10^3],'Color', 'red')
    line([0 limit], [-125*10^3 -125*10^3],'Color', 'red')
    legend("Thruster 2","Thruster 2 w/ fail"); 
    xlabel("Time [s]"); 
    ylabel("N");
    xlim([0 1700]);
    ylim([-170e3 170e3]);

    ax3 = nexttile; 
  	plot(ax3,Time , U3); hold on;
    plot(ax3,Time, U3F); hold on; grid on; 
    line([0 limit], [150*10^3 150*10^3],'Color', 'red')
    line([0 limit], [-150*10^3 -150*10^3],'Color', 'red')
    legend("Thruster 3","Thruster 3 w/ fail");
    xlabel("Time [s]"); 
    ylabel("N");
    ylim([-200e3 200e3]);
    xlim([0 1700]);
    
    ax4 = nexttile; 
    plot(ax4,Time , U4); hold on; grid on; 
    plot(ax4,Time,U4F); hold on; grid on; 
    line([0 limit], [320*10^3 320*10^3],'Color', 'red')
    line([0 limit], [-320*10^3 -320*10^3],'Color', 'red')
    legend("Thruster 4","Thruster 4 w/ fail"); 
    xlabel("Time [s]"); 
    ylabel("N");
    ylim([-375e3 375e3]);
    
    ax5 = nexttile; 
    plot(ax5,Time , U5); hold on; grid on; 
    plot(ax5,Time,U5F); hold on; grid on; 
    line([0 limit], [320*10^3 320*10^3],'Color', 'red')
    line([0 limit], [-320*10^3 -320*10^3],'Color', 'red')
    legend("Thruster 5","Thruster 5 w/ fail"); 
    xlabel("Time [s]");
    ylabel("N");
    ylim([-375e3 375e3]);
    xlim([0 1700]);
    
    
    
    
    
elseif simulation == "Simulation3"
%Simulation 3 
    %Time 
    Time = Simulation3{16}.Values.Time;

    %References 
    %EtaRef 
    NorthRef = Simulation3{15}.Values.Data(:,1);
    EastRef = Simulation3{15}.Values.Data(:,2);
    HeadingRef = Simulation3{15}.Values.Data(:,3);

    %NuRef
    NorthNuRef = Simulation3{16}.Values.Data(:,1);
    EastNuRef = Simulation3{16}.Values.Data(:,2);
    HeadingNuRef = Simulation3{16}.Values.Data(:,3);

    %Real values
    %Eta
    North = Simulation3{17}.Values.Data(:,1);
    East = Simulation3{17}.Values.Data(:,2);
    Heading  = Simulation3{17}.Values.Data(:,3);

    %Nu
    NorthNu = Simulation3{18}.Values.Data(:,1);
    EastNu = Simulation3{18}.Values.Data(:,2);
    HeadingNu = Simulation3{18}.Values.Data(:,3);

    %Estimations
    %Eta
    NorthEst = Simulation3{9}.Values.Data(:,1);
    EastEst = Simulation3{9}.Values.Data(:,2);
    HeadingEst = Simulation3{9}.Values.Data(:,3); 

    %Nu 
    NorthNuEst = Simulation3{10}.Values.Data(:,1);
    EastNuEst = Simulation3{10}.Values.Data(:,2);
    HeadingNuEst = Simulation3{10}.Values.Data(:,3);

    %Thrusters 
    U1 = Simulation3{21}.Values.Data(:,1);
    U2 = Simulation3{21}.Values.Data(:,2);
    U3 = Simulation3{21}.Values.Data(:,3);
    U4 = Simulation3{21}.Values.Data(:,4);
    U5 = Simulation3{21}.Values.Data(:,5);
    
    %Alpha 
    A1 = Simulation3{20}.Values.Data(:,1);
    A2 = Simulation3{20}.Values.Data(:,2);
    A3 = Simulation3{20}.Values.Data(:,3);
    A4 = Simulation3{20}.Values.Data(:,4);
    A5 = Simulation3{20}.Values.Data(:,5);
    
    %Plot 
    figure(1);
    clf(figure(1));
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time , North); hold on;
    %plot(ax1,Time,NorthW); hold on; grid on; 
    plot(ax1,Time, NorthRef); hold on;
    legend("North","North reference"); 
    xlabel("Time [s]"); 
    ylabel("[m]");
    xlim([0 1700])

    ax2 = nexttile; 
    plot(ax2,Time,East); hold on; grid on; 
    %plot(ax2,Time,EastW); hold on; grid on; 
    plot(ax2,Time,EastRef); hold on;
    legend("East","East reference");
    xlabel("Time [s]"); 
    ylabel("[m]");
    ylim([-60 5]);
    xlim([0 1700])

    ax3 = nexttile; 
    plot(ax3,Time,Heading*180/pi); hold on; grid on; 
    %plot(ax3,Time,HeadingW*180/pi); hold on; grid on; 
    plot(ax3,Time,HeadingRef*180/pi); hold on; grid on; 
    legend("Heading","Heading reference");
    xlabel("Time [s]"); 
    ylabel("[deg]");
    ylim([-50 10]);
    xlim([0 1700])
    
    
    figure(2); %Velocities
    clf(figure(2));
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time , NorthNu); hold on; grid on; 
    plot(ax1,Time, NorthNuRef); hold on;
    legend("North","North reference"); 
    xlabel("Time [s]"); 
    ylabel("[m/s]");
    %ylim([-1.2 1.2]);
    xlim([0 1700]);

    ax2 = nexttile; 
    plot(ax2,Time,EastNu); hold on; grid on; 
    plot(ax2,Time,EastNuRef); hold on; grid on; 
    legend("East","East reference");
    xlabel("Time [s]"); 
    ylabel("[m/s]");
    %ylim([-1.2 1.2]);
    xlim([0 1700]);

    ax3 = nexttile; 
    plot(ax3,Time,HeadingNu*180/pi); hold on; grid on;
    plot(ax3,Time,HeadingNuRef*180/pi); hold on; grid on; 
    legend("Heading","Heading reference");
    xlabel("Time [s]"); 
    ylabel("[deg/s]");
    xlim([0 1700]);

    %Heading visualization: 
    X = []; 
    Y = [];
    U = [];
    V = [];

    for i = 1:1:1
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end

    for i = 2000:100:2800
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end

    for i = 4000:100:5900
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end
    
    for i = 5900:150:8100
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end
    
    for i = 8200:100:9500
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end
    for i = 11200:75:13000
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end

    
    figure(3);
    clf(figure(3));
    plot(East,North); hold on;
    %plot(EastW,NorthW); hold on; grid on; 
    plot(EastRef,NorthRef); hold on;
    %plot(EastEst,NorthEst); hold on;
    quiver(X,Y,U,V,0.33); hold on; grid on; 
    xlabel("East [m]");
    ylabel("North [m]"); 
    legend("Real position","Reference","Heading");%, "Estimate");
    
    x = 1700;
    figure(4); 
    clf(figure(4));
    t = tiledlayout(5,1); 
    ax1 = nexttile; 
    plot(ax1,Time , U1); hold on; grid on; 
    %plot(ax1,Time,U1W); hold on;
    line([0 x], [125*10^3 125*10^3],'Color', 'red')
    line([0 x], [-125*10^3 -125*10^3],'Color', 'red')
    legend("Thruster 1"); 
    xlabel("Time [s]"); 
    ylabel("N");
    ylim([-140e3 140e3]);
    xlim([0 x]);

    ax2 = nexttile; 
    plot(ax2,Time , U2); hold on; grid on; 
    %plot(ax2,Time,U2W); hold on;
    line([0 x], [125*10^3 125*10^3],'Color', 'red')
    line([0 x], [-125*10^3 -125*10^3],'Color', 'red')
    legend("Thruster 2"); 
    xlabel("Time [s]"); 
    ylabel("N");
    ylim([-140e3 140e3]);
    xlim([0 x]);

    ax3 = nexttile; 
  	plot(ax3,Time , U3); hold on; grid on; 
    %plot(ax3,Time,U3W); hold on;
    line([0 x], [150*10^3 150*10^3],'Color', 'red')
    line([0 x], [-150*10^3 -150*10^3],'Color', 'red')
    legend("Thruster 3"); 
    xlabel("Time [s]"); 
    ylabel("N");
    ylim([-200e3 200e3]);
    xlim([0 x]);
    
    ax4 = nexttile; 
    plot(ax4,Time , U4); hold on; grid on; 
    %plot(ax4,Time,U4W); hold on;
    line([0 x], [320*10^3 320*10^3],'Color', 'red')
    line([0 x], [-320*10^3 -320*10^3],'Color', 'red')
    legend("Thruster 4"); 
    xlabel("Time [s]"); 
    ylabel("N");
    ylim([-370e3 370e3]);
    xlim([0 x]);
    
    ax5 = nexttile; 
    plot(ax5,Time , U5); hold on; grid on; 
    %plot(ax5,Time,U5W); hold on;
    line([0 x], [320*10^3 320*10^3],'Color', 'red')
    line([0 x], [-320*10^3 -320*10^3],'Color', 'red')
    legend("Thruster 5"); 
    xlabel("Time [s]"); 
    ylabel("N");
    ylim([-370e3 370e3]);
    xlim([0 x]);
   
    figure(5)
    clf(figure(5));
    plot(Time,A4*180/pi); hold on; grid on; 
    plot(Time,A5*180/pi); hold on; grid on; 
    %plot(Time,A4W*180/pi); hold on; grid on; 
    %plot(Time,A5W*180/pi); hold on; grid on; 
    legend("A4", "A5", "A4W", "A5W");
    
    figure(6)
    clf(figure(6));
    plot(Time,U4); hold on; grid on; 
    plot(Time,U5); hold on; grid on; 
    %plot(Time,U4W); hold on; grid on; 
    %plot(Time,U4W); hold on; grid on; 
    legend("U4", "U5", "U4W", "U5W");
    
elseif simulation == "Simulation4"
%Simulation 4 
if simulation == "simulation4_nowaves"
    Time = simulation4_nowaves{14}.Values.Time;
    
    
    %Real values
    %Eta
    North = simulation4_nowaves{18}.Values.Data(:,1);
    East = simulation4_nowaves{18}.Values.Data(:,2);
    Heading  = simulation4_nowaves{18}.Values.Data(:,3);
    
   %Nu
    NorthNu = simulation4_nowaves{19}.Values.Data(:,1);
    EastNu = simulation4_nowaves{19}.Values.Data(:,2);
    HeadingNu = simulation4_nowaves{19}.Values.Data(:,2);

    %Estimations
    %Eta_Kalman
    NorthEst_Kalman = simulation4_nowaves{9}.Values.Data(:,1);
    EastEst_Kalman = simulation4_nowaves{9}.Values.Data(:,2);
    HeadingEst_Kalman = simulation4_nowaves{9}.Values.Data(:,3); 

    %Nu_Kalman
    NorthNuEst_Kalman = simulation4_nowaves{10}.Values.Data(:,1);
    EastNuEst_Kalman = simulation4_nowaves{10}.Values.Data(:,2);
    HeadingNuEst_Kalman = simulation4_nowaves{10}.Values.Data(:,3);
    
    %Eta_NPO
    NorthEst_NPO = simulation4_nowaves{11}.Values.Data(:,1);
    EastEst_NPO = simulation4_nowaves{11}.Values.Data(:,2);
    HeadingEst_NPO = simulation4_nowaves{11}.Values.Data(:,3);
    
    %Nu_NPO
    NorthNuEst_NPO = simulation4_nowaves{12}.Values.Data(:,1);
    EastNuEst_NPO = simulation4_nowaves{12}.Values.Data(:,2);
    HeadingNuEst_NPO = simulation4_nowaves{12}.Values.Data(:,3);
    
    
    %Plot 
    figure(1);
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time,North); hold on; grid on; 
    plot(ax1,Time,NorthEst_Kalman); hold on; grid on;
    plot(ax1,Time,NorthEst_NPO); hold on; grid on;
    legend("Real North", "Estimated North Kalman","Estimated North NPO"); 
    xlabel("Time [s]"); 
    ylabel("[m]");

    ax2 = nexttile; 
    plot(ax2,Time,East); hold on; grid on; 
    plot(ax2,Time,EastEst_Kalman); hold on; grid on;
    plot(ax2,Time,EastEst_NPO); hold on; grid on;
    legend("Real East", "Estimated East Kalman", "Estimated East NPO");
    xlabel("Time [s]"); 
    ylabel("[m]");
    %ylim([-10 5]);

    ax3 = nexttile; 
    plot(ax3,Time,Heading*180/pi); hold on; grid on;
    plot(ax3,Time,HeadingEst_Kalman*180/pi); hold on; grid on;
    plot(ax3,Time,HeadingEst_NPO*180/pi); hold on; grid on;
    legend("Real Heading", "Estimated Heading Kalman", "Estimated Heading NPO");
    xlabel("Time [s]"); 
    ylabel("[deg]");
    %ylim([-10 10]);
    
    
    figure(2);
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time,NorthNu); hold on; grid on; 
    plot(ax1,Time,NorthNuEst_Kalman); hold on; grid on;
    plot(ax1,Time,NorthNuEst_NPO); hold on; grid on;
    legend("Real velocity North", "Estimated velocity North Kalman","Estimated velocity North NPO"); 
    xlabel("Time [s]"); 
    ylabel("[m/s]");

    ax2 = nexttile; 
    plot(ax2,Time,EastNu); hold on; grid on; 
    plot(ax2,Time,EastNuEst_Kalman); hold on; grid on;
    plot(ax2,Time,EastNuEst_NPO); hold on; grid on;
    legend("Real velocity East", "Estimated velocity East Kalman", "Estimated velocity East NPO");
    xlabel("Time [s]"); 
    ylabel("[m/s]");
    %ylim([-10 5]);

    ax3 = nexttile; 
    plot(ax3,Time,HeadingNu*180/pi); hold on; grid on;
    plot(ax3,Time,HeadingNuEst_Kalman*180/pi); hold on; grid on;
    plot(ax3,Time,HeadingNuEst_NPO*180/pi); hold on; grid on;
    legend("Real velocity Heading", "Estimated velocity Heading Kalman", "Estimated velocity Heading NPO");
    xlabel("Time [s]"); 
    ylabel("[deg/s]");
    %ylim([-10 10]);
    
elseif simulation == "simulation4_waves"
    Time = simulation4_waves{14}.Values.Time;
    
    %References 
    %EtaRef 
    %NorthRef = simulation4_nowaves{17}.Values.Data(:,1);
    %EastRef = simulation4_nowaves{17}.Values.Data(:,2);
    %HeadingRef = simulation4_nowaves{17}.Values.Data(:,3);
    
    %Real values
    %Eta
    North = simulation4_waves{18}.Values.Data(:,1);
    East = simulation4_waves{18}.Values.Data(:,2);
    Heading  = simulation4_waves{18}.Values.Data(:,3);
    
   %Nu
    NorthNu = simulation4_waves{19}.Values.Data(:,1);
    EastNu = simulation4_waves{19}.Values.Data(:,2);
    HeadingNu = simulation4_waves{19}.Values.Data(:,2);

    %Estimations
    %Eta_Kalman
    NorthEst_Kalman = simulation4_waves{9}.Values.Data(:,1);
    EastEst_Kalman = simulation4_waves{9}.Values.Data(:,2);
    HeadingEst_Kalman = simulation4_waves{9}.Values.Data(:,3); 

    %Nu_Kalman
    NorthNuEst_Kalman = simulation4_waves{10}.Values.Data(:,1);
    EastNuEst_Kalman = simulation4_waves{10}.Values.Data(:,2);
    HeadingNuEst_Kalman = simulation4_waves{10}.Values.Data(:,3);
    
    %Eta_NPO
    NorthEst_NPO = simulation4_waves{11}.Values.Data(:,1);
    EastEst_NPO = simulation4_waves{11}.Values.Data(:,2);
    HeadingEst_NPO = simulation4_waves{11}.Values.Data(:,3);
    
    %Nu_NPO
    NorthNuEst_NPO = simulation4_waves{12}.Values.Data(:,1);
    EastNuEst_NPO = simulation4_waves{12}.Values.Data(:,2);
    HeadingNuEst_NPO = simulation4_waves{12}.Values.Data(:,3);
    
    
    %Plot 
    figure(1);
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time,North); hold on; grid on; 
    plot(ax1,Time,NorthEst_Kalman); hold on; grid on;
    plot(ax1,Time,NorthEst_NPO); hold on; grid on;
    legend("Real North", "Estimated North Kalman","Estimated North NPO"); 
    xlabel("Time [s]"); 
    ylabel("[m]");

    ax2 = nexttile; 
    plot(ax2,Time,East); hold on; grid on; 
    plot(ax2,Time,EastEst_Kalman); hold on; grid on;
    plot(ax2,Time,EastEst_NPO); hold on; grid on;
    legend("Real East", "Estimated East Kalman", "Estimated East NPO");
    xlabel("Time [s]"); 
    ylabel("[m]");
    %ylim([-10 5]);

    ax3 = nexttile; 
    plot(ax3,Time,Heading*180/pi); hold on; grid on;
    plot(ax3,Time,HeadingEst_Kalman*180/pi); hold on; grid on;
    plot(ax3,Time,HeadingEst_NPO*180/pi); hold on; grid on;
    legend("Real Heading", "Estimated Heading Kalman", "Estimated Heading NPO");
    xlabel("Time [s]"); 
    ylabel("[deg]");
    %ylim([-10 10]);
    
    
    figure(2);
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time,NorthNu); hold on; grid on; 
    plot(ax1,Time,NorthNuEst_Kalman); hold on; grid on;
    plot(ax1,Time,NorthNuEst_NPO); hold on; grid on;
    legend("Real velocity North", "Estimated velocity North Kalman","Estimated velocity North NPO"); 
    xlabel("Time [s]"); 
    ylabel("[m/s]");

    ax2 = nexttile; 
    plot(ax2,Time,EastNu); hold on; grid on; 
    plot(ax2,Time,EastNuEst_Kalman); hold on; grid on;
    plot(ax2,Time,EastNuEst_NPO); hold on; grid on;
    legend("Real velocity East", "Estimated velocity East Kalman", "Estimated velocity East NPO");
    xlabel("Time [s]"); 
    ylabel("[m/s]");
   

    ax3 = nexttile; 
    plot(ax3,Time,HeadingNu*180/pi); hold on; grid on;
    plot(ax3,Time,HeadingNuEst_Kalman*180/pi); hold on; grid on;
    plot(ax3,Time,HeadingNuEst_NPO*180/pi); hold on; grid on;
    legend("Real velocity Heading", "Estimated velocity Heading Kalman", "Estimated velocity Heading NPO");
    xlabel("Time [s]"); 
    ylabel("[deg/s]");
    
    

     
elseif simulation == "Simulation5"
%Simulation 5 

    %Time 

    Time = Simulation5{16}.Values.Time;

    %References 
    %EtaRef 
    NorthRef = Simulation5{14}.Values.Data(:,1);
    EastRef = Simulation5{14}.Values.Data(:,2);
    HeadingRef = Simulation5{14}.Values.Data(:,3);

    %NuRef
    NorthNuRef = Simulation5{15}.Values.Data(:,1);
    EastNuRef = Simulation5{15}.Values.Data(:,2);
    HeadingNuRef = Simulation5{15}.Values.Data(:,3);
    
    %Real values
    %Eta
    North = Simulation5{16}.Values.Data(:,1);
    East = Simulation5{16}.Values.Data(:,2);
    Heading  = Simulation5{16}.Values.Data(:,3);

    %Nu
    NorthNu = Simulation5{17}.Values.Data(:,1);
    EastNu = Simulation5{17}.Values.Data(:,2);
    HeadingNu = Simulation5{17}.Values.Data(:,3);

    %Estimations
    %Eta
    NorthEst = Simulation5{8}.Values.Data(:,1);
    EastEst = Simulation5{8}.Values.Data(:,2);
    HeadingEst = Simulation5{8}.Values.Data(:,3); 

    %Nu 
    NorthNuEst = Simulation5{9}.Values.Data(:,1);
    EastNuEst = Simulation5{9}.Values.Data(:,2);
    HeadingNuEst = Simulation5{9}.Values.Data(:,3);

    
    %Thrusters 
    U1 = Simulation5{20}.Values.Data(:,1);
    U2 = Simulation5{20}.Values.Data(:,2);
    U3 = Simulation5{20}.Values.Data(:,3);
    U4 = Simulation5{20}.Values.Data(:,4);
    U5 = Simulation5{20}.Values.Data(:,5);
    
    %Alpha 
    A1 = Simulation5{19}.Values.Data(:,1);
    A2 = Simulation5{19}.Values.Data(:,2);
    A3 = Simulation5{19}.Values.Data(:,3);
    A4 = Simulation5{19}.Values.Data(:,4);
    A5 = Simulation5{19}.Values.Data(:,5);
    
    %Thruster Dynamics 
    Thrust1 = Simulation5{18}.Values.Data(:,1);
    Thrust2 = Simulation5{18}.Values.Data(:,2);
    Thrust6 = Simulation5{18}.Values.Data(:,6);
    
    %Controller Tau
    Tau1 = Simulation5{4}.Values.Data(:,1); 
    Tau2 = Simulation5{4}.Values.Data(:,2);
    Tau6 = Simulation5{4}.Values.Data(:,6);
    
    
    limit = 1700;
    %Plot 
    figure(1);
    clf(figure(1));
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time , North); hold on; grid on; 
    plot(ax1,Time,NorthEst); hold on; grid on; 
    plot(ax1,Time, NorthRef); hold on; grid on;
    legend("North", "Estimated North","North reference"); 
    xlabel("Time [s]"); 
    ylabel("[m]");
    ylim([-10 60]);
    xlim([0 limit]);

    ax2 = nexttile; 
    plot(ax2,Time,East); hold on; grid on; 
    plot(ax2,Time,EastEst); hold on; grid on; 
    plot(ax2,Time,EastRef); hold on; grid on; 
    legend("East", "Estimated East","East reference");
    xlabel("Time [s]"); 
    ylabel("[m]");
    ylim([-60 10]);
    xlim([0 limit]);

    ax3 = nexttile; 
    plot(ax3,Time,Heading*180/pi); hold on; grid on; 
    plot(ax3,Time,HeadingEst*180/pi); hold on; grid on; 
    plot(ax3,Time,HeadingRef*180/pi); hold on; grid on; 
    legend("Heading ", "Estimated Heading","Heading reference");
    xlabel("Time [s]"); 
    ylabel("[deg]");
    ylim([-60 10]);
    xlim([0 limit]);

    %Heading visualization: 
    X = []; 
    Y = [];
    U = [];
    V = [];

    for i = 1:1:1
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end

    for i = 2000:100:2800
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end

    for i = 4000:100:5900
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end

    for i = 5900:150:8100
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end
    for i = 8200:100:9500
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end
    for i = 11200:75:13000
        X = [X East(i)];
        Y = [Y North(i)];
        U = [U sin(Heading(i))];
        V = [V cos(Heading(i))];
    end


    figure(2); %XY plot
    clf(figure(2));
    plot(East,North); hold on;
    plot(EastRef,NorthRef); hold on; grid on; 
    plot(EastEst,NorthEst); hold on;
    quiver(X,Y,U,V,0.33); hold on; grid on; 
    xlabel("East [m]");
    ylabel("North [m]"); 
    legend("Pos", "Reference", "Estimate","Heading of ship");


    figure(3); %Velocities
    clf(figure(3));
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time , NorthNu); hold on; grid on; 
    plot(ax1,Time,NorthNuEst); hold on; grid on; 
    plot(ax1,Time, NorthNuRef); hold on;
    legend("North", "Estimated North","North reference"); 
    xlabel("Time [s]"); 
    ylabel("[m/s]");
    ylim([-1.2 1.2]);

    ax2 = nexttile; 
    plot(ax2,Time,EastNu); hold on; grid on; 
    plot(ax2,Time,EastNuEst); hold on; grid on; 
    plot(ax2,Time,EastNuRef); hold on; grid on; 
    legend("East", "Estimated East","East reference");
    xlabel("Time [s]"); 
    ylabel("[m/s]");
    ylim([-1.2 1.2]);

    ax3 = nexttile; 
    plot(ax3,Time,HeadingNu*180/pi); hold on; grid on; 
    plot(ax3,Time,HeadingNuEst*180/pi); hold on; grid on; 
    plot(ax3,Time,HeadingNuRef*180/pi); hold on; grid on; 
    legend("Heading", "Estimated Heading","Heading reference");
    xlabel("Time [s]"); 
    ylabel("[deg/s]");
    %ylim([-65 65]);
    
    limit = 1700;
    figure(4) %Thruster dynamics
    clf(figure(4)); 
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time,Tau1); hold on; grid on; 
    plot(ax1,Time,Thrust1); hold on; grid on; 
    legend("Controller", "Thruster dynamics");
    xlabel("Time [s]"); 
    ylabel("N");
    xlim([0 limit]);
    
    ax2 = nexttile; 
    plot(ax2,Time,Tau2); hold on; grid on; 
    plot(ax2,Time,Thrust2); hold on; grid on; 
    legend("Controller", "Thruster dynamics");
    xlabel("Time [s]"); 
    ylabel("N");
    xlim([0 limit]);
    
    ax3 = nexttile;
    plot(ax3,Time,Tau6); hold on; grid on; 
    plot(ax3,Time,Thrust6); hold on; grid on; 
    legend("Controller", "Thruster dynamics");
    xlabel("Time [s]"); 
    ylabel("N");
    xlim([0 limit]);
    
    figure(5); 
    clf(figure(5));
    t = tiledlayout(5,1); 
    ax1 = nexttile; 
    plot(ax1,Time , U1); hold on; grid on; 
    line([0 limit], [125*10^3 125*10^3],'Color', 'red')
    line([0 limit], [-125*10^3 -125*10^3],'Color', 'red')
    legend("Thruster 1"); 
    xlabel("Time [s]"); 
    ylabel("N");
    ylim([-140e3 140e3]);
    xlim([0 limit]);

    ax2 = nexttile; 
    plot(ax2,Time , U2); hold on; grid on; 
    line([0 limit], [125*10^3 125*10^3],'Color', 'red')
    line([0 limit], [-125*10^3 -125*10^3],'Color', 'red')
    legend("Thruster 2"); 
    xlabel("Time [s]"); 
    ylabel("N");
    ylim([-140e3 140e3]);
    xlim([0 limit]);
    
    ax3 = nexttile; 
  	plot(ax3,Time , U3); hold on;
    line([0 limit], [150*10^3 150*10^3],'Color', 'red')
    line([0 limit], [-150*10^3 -150*10^3],'Color', 'red')
    legend("Thruster 3");
    xlabel("Time [s]"); 
    ylabel("N");
    ylim([-200e3 200e3]);
    xlim([0 limit]);
    
    ax4 = nexttile; 
    plot(ax4,Time , U4); hold on; grid on; 
    line([0 limit], [320*10^3 320*10^3],'Color', 'red')
    line([0 limit], [-320*10^3 -320*10^3],'Color', 'red')
    legend("Thruster 4"); 
    xlabel("Time [s]"); 
    ylabel("N");
    ylim([-350e3 350e3]);
    xlim([0 limit]);
    
    ax5 = nexttile; 
    plot(ax5,Time , U5); hold on; grid on; 
    line([0 limit], [320*10^3 320*10^3],'Color', 'red')
    line([0 limit], [-320*10^3 -320*10^3],'Color', 'red')
    legend("Thruster 5"); 
    xlabel("Time [s]");
    ylabel("N");
    ylim([-350e3 350e3]);
    xlim([0 limit]);
    
elseif simulation == "Simulation6"
%Simulation 6 


elseif simulation == "Simulation7"
%Simulation 7 

    %Time 

    Time = Simulation7{14}.Values.Time;
    
    %References 
    %EtaRef 
    NorthRef = Simulation7{14}.Values.Data(:,1);
    EastRef = Simulation7{14}.Values.Data(:,2);
    HeadingRef = Simulation7{14}.Values.Data(:,3);
    
    %Real values
    %Eta
    North = Simulation7{16}.Values.Data(:,1);
    East = Simulation7{16}.Values.Data(:,2);
    Heading  = Simulation7{16}.Values.Data(:,3);
    
    %Nu
    NorthNu = Simulation7{17}.Values.Data(:,1);
    EastNu = Simulation7{17}.Values.Data(:,2);
    HeadingNu = Simulation7{17}.Values.Data(:,3);

    %Estimations
    %Eta
    NorthEst = Simulation7{8}.Values.Data(:,1);
    EastEst = Simulation7{8}.Values.Data(:,2);
    HeadingEst = Simulation7{8}.Values.Data(:,3); 

    %Nu 
    NorthNuEst = Simulation7{9}.Values.Data(:,1);
    EastNuEst = Simulation7{9}.Values.Data(:,2);
    HeadingNuEst = Simulation7{9}.Values.Data(:,3);

    %Plot 
    figure(1);
    clf(figure(1))
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time,North); hold on; grid on; 
    plot(ax1,Time,NorthEst); hold on;
    legend("North", "Estimated North"); 
    xlabel("Time [s]"); 
    ylabel("[m]");

    ax2 = nexttile; 
    plot(ax2,Time,East); hold on; grid on; 
    plot(ax2,Time,EastEst); hold on;
    legend("East", "Estimated East");
    xlabel("Time [s]"); 
    ylabel("[m]");
    

    ax3 = nexttile; 
    plot(ax3,Time,Heading*180/pi); hold on; grid on; 
    plot(ax3,Time,HeadingEst*180/pi); hold on; grid on; 
    legend("Heading", "Estimated Heading");
    xlabel("Time [s]"); 
    ylabel("[deg]");
    
    
    figure(2);
    clf(figure(2));
    plot(East,North); hold on; grid on;
    %plot(EastEst,NorthEst); hold on; grid on; 
    %quiver(X,Y,U,V,0.33); hold on; grid on; 
    xlabel("East [m]");
    ylabel("North [m]"); 
    legend("Pos", "Estimated");
    %xlim([-2 0.5]);
    %ylim([-0.5 0.3]);
    
    
    figure(3);
    clf(figure(3))
    t = tiledlayout(3,1); 
    ax1 = nexttile; 
    plot(ax1,Time,NorthNu); hold on; grid on; 
    plot(ax1,Time,NorthNuEst); hold on;
    legend("North", "Estimated North"); 
    xlabel("Time [s]"); 
    ylabel("[m/s]");

    ax2 = nexttile; 
    plot(ax2,Time,EastNu); hold on; grid on; 
    plot(ax2,Time,EastNuEst); hold on;
    legend("East", "Estimated East");
    xlabel("Time [s]"); 
    ylabel("[m/s]");
    

    ax3 = nexttile; 
    plot(ax3,Time,HeadingNu*180/pi); hold on; grid on; 
    plot(ax3,Time,HeadingNuEst*180/pi); hold on; grid on; 
    legend("Heading", "Estimated Heading");
    xlabel("Time [s]"); 
    ylabel("[deg/s]");
    
    MeanNorth = mean(North)
    MeanEast = mean(East)
else 
    disp("Wrong keyword");
    
end 