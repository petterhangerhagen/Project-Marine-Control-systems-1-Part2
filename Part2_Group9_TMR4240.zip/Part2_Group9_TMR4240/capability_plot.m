load('cpTable.mat');

% init
N = 6*3;
r = 0: 200/N:100;
t = pi/2:pi/N:5/2*pi;
count = 0;

% Make capability plot without data
for i = t
    % Polar coordinates.
    x = r*cos(i);
    y = r*sin(i);
    
    % mark with one line per 10th degree 
    if (count < 37)
        plot(x, y, 'b:')
        if count > 0            
            % Indicating angles on the outline of circle
            text(cos(i)*110, sin(i).*110, ...
                join(int2str(360 - count*10), '°'), ...      
                'VerticalAlignment','middle', ...
                'HorizontalAlignment','center');
        end
    end
    
    % Plot percent lables from 0 -> 100, step 10
    if (count <= 10)
        plot(count*10*cos(t), count*10*sin(t), 'Color', [200 200 200]/256)
        
        text(-10, count*10, join(int2str(count*10), '°'), ...
                'FontSize', 8,...
                'VerticalAlignment','middle', ...
                'HorizontalAlignment','center');
    end
    
    % Gather all functions in one plot, and increment count.
    hold on
    count = count + 1;
end  


% Plot initialisating
lim = 160;
xlim([-lim lim]);
ylim([-lim lim]);
title("Average Trust utilization (%)")
text(0, 130, "Average Trust utilization (%)", ...
    'VerticalAlignment','middle', ...
    'HorizontalAlignment','center');
cpList = [];
for i = 1:size(cpThruster_Ultimate_table,2)
     avg = sum(cpThruster_Ultimate_table(2000:5001,i))/size(cpThruster_Ultimate_table(2000:5001),2);
     cpList(end+1) = avg;
    
end

% Data points should be distributed equally with step of 10 deegrees
% and start with 0 degrees.
thrust_utilisation_plot(cpList*100); 

function thrust = thrust_utilisation_plot(data)
    %Define angles
    t = pi*5/2:-2*pi/(size(data,2)-1):1/2*pi;
    
    %generate Capability plot
    x = data.*cos(t);
    y = data.*sin(t);
    plot(x, y,"o",'MarkerFaceColor', [253 134 18]/256, ...
        'color', [253 134 18]/256, ...
        'LineWidth', 1) 
    hold on;
    plot(x, y, ...
        'color', [253 134 18]/256, ...
        'LineWidth', 1)
    
    hold off;
end


