%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init()                                                                  %
%                                                                         %              
% Set initial parameters for part1.slx and part2.slx                      %
%                                                                         %
% Created:      2018.07.12	Jon Bj�rn�                                    %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;

load('supply.mat');
load('supplyABC.mat');
load('thrusters_sup.mat')
addpath(genpath('C:\Users\vegar\Documents\MATLAB\Marine reguleringssystemer\Prosjekt part 2'));
%mssSimulink

% Initial position x, y, z, phi, theta, psi
eta0 = [0,0,0,0,0,0]';
% Initial velocity u, v, w, p, q, r
nu0 = [0,0,0,0,0,0]';

%% Simulations
%% Wind parameters
kappa = 0.0026;
mu = 0.001; %white noise for wind
mu_angle = 0.1; %white noise for angle
omega = 0.005; % White noise power

phi = zeros(1, 100);
for i = 1:length(phi)
    phi(i) = 2*pi*rand(1);
end

%% Simulation 1 values
% Current from East
current_dir = 3*pi/2;
Vc = 0.2;
nu_c = [Vc*cos(current_dir),Vc*sin(current_dir),0,0,0,0]';

% Wind from North
wind_dir = pi;
U_z = 10;


% Waves from Northeast
wave_dir = 5*pi/4;
Hs = 2.5;
Tp = 9;
omega_p = 2*pi/Tp;

% Referanse
% Endrer p� denne til posisjonen vi vil til
etaref = [0,0,0]';



%% WP sim2 og 3 
etaref0 = [0,0,0]';
etaref1 = [500,0,0]';
etaref2 = [500,-500,0]';
etaref3 = [50,-50,-pi/4]';
etaref4 = [0,-50,-pi/4]';
etaref5 = [0,0,0]';

wp = [etaref0, etaref1, etaref2, etaref3, etaref4, etaref5];


%%%%%%%%%%%%%%%%%%%%%%PID%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Damping ratio
zeta = 1; %Dong snakket om � bruke 0.7, men kan variere denne litt. 1 er maks

%Mass
m = 6.3622*10^6; %Hentet fra supply.mat filen
m_yaw = 2726143000;

%Mass included added mss
A(:,:,1) = reshape(vessel.A(:,:,20,1),6,6,1);
A(:,:,1);
Msurge = m + A(1,1,1);
Msway = m + A(2,2,1);
Myaw = m_yaw + A(6,6,1);


%For N
TnN = 15; %Naturlig periode 
TiN = 200; %Time constant
KpN = (2*pi/TnN)^2 *Msurge;
KdN = zeta* 2*sqrt(KpN*Msurge);
KiN = KpN/TiN;

%For E 
TnE = 15;
TiE = 200;
KpE = (2*pi/TnE)^2 * Msway;
KdE = zeta*2*sqrt(KpE*Msway);
KiE= KpE/TiE ;

%For yaw
TnY = 15;
TiY = 200;
KpY = (2*pi/TnY)^2 * Myaw;
KdY = zeta*2*sqrt(KpY*Myaw);
KiY = KpY/TiY;

s = 0.05; 
Kd = [0.2*KdN,0.2*KdE,2.5*KdY]*s';
Kp = [1.2*KpN 1.5*KpE 1.5*KpY]*s';
Ki = [1.2*KiN,2.5*KiE,KiY]*s';







%%%%%%%%%%Reference model%%%%%%%%
%Benyttes for som inital verdier i integreringen i referanse modellen
eta01 = [eta0(1),eta0(2),eta0(6)];
w_n = [0.045,0.035,0.04]';    
zetas = [zeta,zeta,zeta]';




%%%%%%%%%Observers%%%%%%%%%%%%
%Choosed passive nonlinear observer and Kalman filter
%%Control plant model
%%%Wave frequency model 
%Natural frequency - Should equal wave peak frequency %%Between 5 to 20
%seconds
wn = 2*pi/9; 

%Cut-off frequency - Should be bigger than natural frequency 1.25-1.3wn
wc = 1.25*wn; 

%Relative damping ratio
zeta_n1 = 1; 
zeta_n = 0.1; 


%Some more specific ratios - between 0.05 and 0.1
zeta1 = 0.05;
zeta2 = 0.075;
zeta3 = 0.1;

%Mass matrix
M = [6.8177e6 0 0
    0 7.8784e6 -2.5955e6
    0 -2.5955e6 3.57e9];

%Damping matrix 
D = [2.6486e5 0 0
    0 8.8164e5 0 
    0 0 3.3774e8];


%System matrix 
Aw = [zeros(3) eye(3)
    -diag([wn,wn,wn]).^2 -2*diag([zeta1,zeta2,zeta3])*diag([wn,wn,wn])];

%Measurment matrix
Cw = [zeros(3,3) eye(3,3)];


Kw = diag([1,1,1]);

Ew = [zeros(3,3)
    Kw];



%%%Bias
%T-matrix - Tb = 1000s OK 
Tb = diag([1000,1000,1000]);


%%%%%%%%%%%%%%%%%Nonlinear observer%%%%%%%%%%%%%%%%%%%%%%%
%Tuning parameters for K-matrices 
%k1 = k2 = k3 
k1 = -2*(zeta_n1 - zeta_n)*wc/wn;
k2 = k1;
k3 = k1;

%k4 = k5 = k6 
k4 = 2*wn*(zeta_n1 - zeta_n);
k5 = k4;
k6 = k4; 

%k7 = k8 = k9 
k7 = wc;
k8 = wc; 
k9 = wc; 

%Tuning parameters
Kt =  0.06;

K1 = 0.005*[diag([k1,k2,k3]);
    diag([k4,k5,k6])];

K2 = 0.06*diag([k7,k8,k9]);

K4 = 0.06*eye(3).*diag(M); %Tuning paramters

K3 = Kt*0.1*K4;


%%%%%%%%%%%%%%%%%Kalman%%%%%%%%%%%%%%

Eb = diag([1,1,1]); %If we are going to use it 

Q1_cov = diag([1,1,1])*0.001; %Noise from WF
Q2_cov = diag([1e6,5e6,1e9]); %Noise from bias 

Q = blkdiag(Q1_cov,Q2_cov);

R = diag([0.01,0.01,0.001]);

    
%Initilizing 
P0 =eye(15)*1;
x0 = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
%x0 = [1 1 1 1 1 1 1 1 1 1 1 1 1 1 1];



%%%%%%%%%%%%%%%%%%%%%%%%Thrust allocation%%%%%%%%%%%%%%%

Thrusters = thrusters([1 2 3 4 5]);

a1 = Thrusters(1).initangle;
a2 = Thrusters(2).initangle;
a3 = Thrusters(3).initangle;
a4 = Thrusters(4).initangle;
a5 = Thrusters(5).initangle;


xpos = [Thrusters(1).xposition Thrusters(2).xposition Thrusters(3).xposition Thrusters(4).xposition Thrusters(5).xposition]  ;
ypos = [Thrusters(1).yposition Thrusters(2).yposition Thrusters(3).yposition Thrusters(4).yposition Thrusters(5).yposition]  ;


 Bal = [0 0 1 0 1 0 1 0
    1 1 0 1 0 1 0 1
    xpos(1) xpos(2) xpos(3) ypos(3) xpos(4) ypos(4) xpos(5) ypos(5)];



%Weighting:

W = diag([0.391 0.391 0.4688 0.4688 1 1 1 1]);
%pinv_B = inv(W)*Bal'*inv(Bal*inv(W)*Bal');
pinv_B = pinv(Bal);

